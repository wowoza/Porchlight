import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { a as Paintbrush, c as Hammer, d as Check, i as ShieldCheck, l as Clock3, n as Wrench, o as Menu, s as MapPin, t as X, u as ClipboardList } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay, c as Slot, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DTPeWC4l.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-full text-sm font-medium transition-colors duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-linen disabled:pointer-events-none disabled:opacity-50 [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-pine text-primary-foreground hover:bg-pine-deep",
			clay: "bg-clay text-accent-foreground hover:bg-clay-deep",
			outline: "border border-line-strong bg-transparent text-ink hover:bg-muted",
			ghost: "text-ink hover:bg-muted",
			inverse: "bg-paper text-ink hover:bg-linen"
		},
		size: {
			default: "h-11 px-5",
			sm: "h-9 px-4 text-xs",
			lg: "h-12 px-7 text-base"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-md border border-line bg-paper px-3 text-sm text-ink placeholder:text-moss/70 outline-none transition-colors focus-visible:border-pine focus-visible:ring-2 focus-visible:ring-pine/20", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-sm font-medium text-ink", className),
		...props
	});
}
var PLANS = [
	{
		id: "essential",
		name: "Essential",
		price: 109,
		hours: "1 hour each month",
		tagline: "Light upkeep for a newer home or a short punch list.",
		includes: [
			"One reserved hour each month",
			"Small drywall patches and nail pops",
			"Caulk, hardware, and door adjustments",
			"Minor paint touch-ups",
			"Free basic consumables",
			"10% off extra labor and full-room work",
			"Written recap after every visit"
		],
		extra: "Member extras billed at $135/hour"
	},
	{
		id: "home-care",
		name: "Home Care",
		price: 159,
		hours: "2 hours each month",
		tagline: "The plan most Lenexa homes actually use.",
		popular: true,
		includes: [
			"One focused two-hour visit each month",
			"Full punch-list plus preventive care",
			"Drywall touch-ups across multiple rooms",
			"Caulk, weatherstripping, and hardware",
			"Furniture hanging and fixture swaps",
			"15% off extra labor and full-room work",
			"Preferred scheduling on clustered routes"
		],
		extra: "Member extras billed at $120/hour"
	},
	{
		id: "premium",
		name: "Premium",
		price: 239,
		hours: "2.5–3 hours each month",
		tagline: "Dedicated time for older homes, busy families, and landlords.",
		includes: [
			"2.5–3 hours monthly, or two shorter visits",
			"Highest-priority scheduling",
			"Proactive seasonal suggestions",
			"Larger free-materials allowance",
			"Bank unused time for one larger project a year",
			"20% off extra labor and materials",
			"The same craftsman who already knows the house"
		],
		extra: "Member extras billed at $110/hour"
	}
];
function InquiryDialog({ open, onOpenChange, defaultPlan }) {
	const [plan, setPlan] = (0, import_react.useState)(defaultPlan);
	const [sending, setSending] = (0, import_react.useState)(false);
	function submit(e) {
		e.preventDefault();
		const data = new FormData(e.currentTarget);
		const payload = {
			name: String(data.get("name") || ""),
			phone: String(data.get("phone") || ""),
			email: String(data.get("email") || ""),
			address: String(data.get("address") || ""),
			plan,
			notes: String(data.get("notes") || ""),
			at: (/* @__PURE__ */ new Date()).toISOString()
		};
		setSending(true);
		window.setTimeout(() => {
			const existing = JSON.parse(localStorage.getItem("porchlight-inquiries") || "[]");
			localStorage.setItem("porchlight-inquiries", JSON.stringify([payload, ...existing].slice(0, 20)));
			setSending(false);
			onOpenChange(false);
			toast.success("Request received", { description: "We’ll text you within one business day to schedule a fit visit." });
		}, 450);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange: (next) => {
			if (next) setPlan(defaultPlan);
			onOpenChange(next);
		},
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-ink/45" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "fixed top-1/2 left-1/2 z-50 w-[min(92vw,32rem)] max-h-[90dvh] -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-2xl bg-paper p-6 shadow-soft outline-none",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-5 flex items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
					className: "font-display text-2xl font-semibold tracking-tight",
					children: "Request a membership"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
					className: "mt-1 text-sm text-moss",
					children: "Tell us the house and the plan. We’ll confirm a first visit — no long contract."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
					className: "inline-flex size-10 items-center justify-center rounded-full hover:bg-muted",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "sr-only",
						children: "Close"
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "grid gap-4",
				onSubmit: submit,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Full name",
						name: "name",
						required: true,
						placeholder: "Alex Rivera"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Phone",
							name: "phone",
							required: true,
							type: "tel",
							placeholder: "(913) 555-0148"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Email",
							name: "email",
							type: "email",
							placeholder: "you@email.com"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Home address",
						name: "address",
						required: true,
						placeholder: "Lenexa, KS"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Plan" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2",
							children: PLANS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setPlan(p.id),
								className: `rounded-lg border px-2 py-2.5 text-center text-xs font-medium transition-colors ${plan === p.id ? "border-pine bg-pine text-primary-foreground" : "border-line bg-linen text-ink hover:border-line-strong"}`,
								children: [p.name, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mt-0.5 block font-normal opacity-80",
									children: ["$", p.price]
								})]
							}, p.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "notes",
							children: "What’s on the list?"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
							id: "notes",
							name: "notes",
							rows: 3,
							placeholder: "Sticky door, hallway cracks, bathroom caulk…",
							className: "w-full resize-none rounded-md border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-pine focus-visible:ring-2 focus-visible:ring-pine/20"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						size: "lg",
						className: "mt-1 w-full",
						disabled: sending,
						children: sending ? "Sending…" : "Send request"
					})
				]
			})]
		})] })
	});
}
function Field({ label, name, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
			htmlFor: name,
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			id: name,
			name,
			...props
		})]
	});
}
function Logo({ className, inverse = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: cn("inline-flex items-center gap-2.5", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 32 32",
			className: "size-8 shrink-0",
			"aria-hidden": "true",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
					width: "32",
					height: "32",
					rx: "8",
					className: inverse ? "fill-linen" : "fill-pine"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M16 6.5c.6 0 1.1.4 1.3 1l.5 1.5h2.4a1.5 1.5 0 0 1 1.5 1.5v2.2c0 2.6-1.6 4.8-3.9 5.7v3.1h1.2a.9.9 0 1 1 0 1.8h-6a.9.9 0 1 1 0-1.8h1.2v-3.1A6.1 6.1 0 0 1 10.3 12.7V11.5A1.5 1.5 0 0 1 11.8 10h2.4l.5-1.5A1.4 1.4 0 0 1 16 6.5Z",
					className: inverse ? "fill-pine" : "fill-linen"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
					d: "M13.2 12.2h5.6v1.1c0 1.7-1.2 3.1-2.8 3.1s-2.8-1.4-2.8-3.1v-1.1Z",
					className: "fill-clay"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-xl font-semibold tracking-tight",
			children: "Porchlight"
		})]
	});
}
var LINKS = [
	{
		href: "#plans",
		label: "Plans"
	},
	{
		href: "#included",
		label: "What’s included"
	},
	{
		href: "#how",
		label: "How it works"
	},
	{
		href: "#area",
		label: "Service area"
	},
	{
		href: "#faq",
		label: "FAQ"
	}
];
function SiteHeader({ onJoin }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 border-b border-line bg-linen/90 backdrop-blur-md",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "#top",
					className: "shrink-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "hidden items-center gap-7 text-sm font-medium text-moss md:flex",
					children: LINKS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: l.href,
						className: "hover:text-ink",
						children: l.label
					}, l.href))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "hidden sm:inline-flex",
						onClick: onJoin,
						children: "Request a visit"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "inline-flex size-11 items-center justify-center rounded-full md:hidden",
						"aria-label": open ? "Close menu" : "Open menu",
						onClick: () => setOpen((v) => !v),
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
					})]
				})
			]
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-line px-4 py-4 md:hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "grid gap-1",
				children: [LINKS.map((l) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: l.href,
					className: "rounded-lg px-3 py-3 text-sm font-medium hover:bg-muted",
					onClick: () => setOpen(false),
					children: l.label
				}, l.href)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					className: "mt-2 w-full",
					onClick: () => {
						setOpen(false);
						onJoin();
					},
					children: "Request a visit"
				})]
			})
		}) : null]
	});
}
var INCLUDED = [
	{
		icon: Hammer,
		title: "Punch-list repairs",
		body: "Doors, hardware, fixtures, hanging, and the small stuff that never gets done."
	},
	{
		icon: Paintbrush,
		title: "Paint & drywall",
		body: "Crack repair, patches, touch-ups — plus full rooms billed as member extras."
	},
	{
		icon: Wrench,
		title: "Preventive care",
		body: "Caulk, weatherstripping, seasonal checks before they become weekend emergencies."
	},
	{
		icon: ShieldCheck,
		title: "Same craftsman",
		body: "One person who already knows the house, not a new crew every visit."
	}
];
var STEPS = [
	{
		n: "01",
		title: "Pick a plan",
		body: "Essential, Home Care, or Premium. Month to month. Cancel with 30 days’ notice."
	},
	{
		n: "02",
		title: "Fit visit",
		body: "We walk the house, set the punch list, and cluster you on a neighborhood route."
	},
	{
		n: "03",
		title: "Monthly care",
		body: "Your reserved hours arrive. We knock out the list, then quote any full-room extras."
	}
];
var FAQS = [
	{
		q: "What’s actually included in the monthly hours?",
		a: "Handyman punch-list work: drywall patches, caulk, doors, hardware, minor paint, hanging, and similar small tasks. Full bedrooms, bathrooms, and larger drywall are quoted as extras at your member rate."
	},
	{
		q: "Can I roll unused hours?",
		a: "Essential and Home Care hours are meant to be used each month so the house stays current. Premium members can bank unused time toward one larger project per year."
	},
	{
		q: "Do I need to buy materials?",
		a: "Basic consumables — caulk, screws, anchors, small spackle — are included. Everything else is billed at cost plus a modest markup, with your plan discount applied."
	},
	{
		q: "Where do you work?",
		a: "Lenexa first, plus clustered routes in Overland Park and Shawnee. Tight geography keeps visits on time and the membership profitable to deliver well."
	},
	{
		q: "Is there a contract?",
		a: "No annual lock-in. Membership is month to month with 30 days’ notice. We’d rather earn the next visit than trap it."
	}
];
function HomePage() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [plan, setPlan] = (0, import_react.useState)("home-care");
	function join(id = "home-care") {
		setPlan(id);
		setOpen(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "top",
		className: "min-h-dvh bg-linen text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, { onJoin: () => join("home-care") }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InquiryDialog, {
				open,
				onOpenChange: setOpen,
				defaultPlan: plan
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				position: "top-center",
				richColors: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "relative overflow-hidden",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-6xl items-center gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:py-20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mb-4 inline-flex items-center gap-2 rounded-full border border-line bg-paper px-3 py-1 text-xs font-medium tracking-wide text-moss uppercase",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-3.5 text-pine" }), "Lenexa · Overland Park · Shawnee"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "font-display text-[2.6rem] leading-[1.08] font-semibold sm:text-5xl lg:text-[3.4rem]",
								children: "The house guy you actually keep."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-5 max-w-xl text-lg leading-relaxed text-moss",
								children: "A monthly handyman membership for Johnson County homes. Reserved hours for the punch list, plus member rates on full bedrooms, bathrooms, and drywall."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-8 flex flex-wrap gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "lg",
									onClick: () => join("home-care"),
									children: "See membership plans"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "lg",
									variant: "outline",
									asChild: true,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
										href: "#plans",
										children: "Compare the three tiers"
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
								className: "mt-10 grid grid-cols-3 gap-4 border-t border-line pt-6",
								children: [
									["4 yrs", "On the tools"],
									["3 tiers", "Clear hours"],
									["30-day", "Notice to cancel"]
								].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "font-display text-2xl font-semibold",
									children: k
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "mt-1 text-xs text-moss",
									children: v
								})] }, k))
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "overflow-hidden rounded-2xl shadow-soft",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: "/images/craftsman.jpg",
									alt: "Craftsman patching drywall in a bright suburban home",
									className: "aspect-[4/3] w-full object-cover"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute -bottom-5 left-4 max-w-[16rem] rounded-xl border border-line bg-paper p-4 shadow-soft sm:left-8",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-wide text-moss uppercase",
									children: "Typical Home Care visit"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 font-display text-lg font-semibold leading-snug",
									children: "Two hours. The list actually gets shorter."
								})]
							})]
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "included",
					className: "border-t border-line bg-paper",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-[0.18em] text-clay uppercase",
								children: "Membership work"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 max-w-2xl font-display text-3xl font-semibold sm:text-4xl",
								children: "Built around what a house actually needs every month."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-10 grid gap-4 sm:grid-cols-2",
								children: INCLUDED.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "rounded-xl border border-line bg-linen p-6",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "size-5 text-pine" }),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
											className: "mt-4 font-display text-xl font-semibold",
											children: item.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm leading-relaxed text-moss",
											children: item.body
										})
									]
								}, item.title))
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "plans",
					className: "border-t border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto max-w-2xl text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium tracking-[0.18em] text-clay uppercase",
									children: "Three tiers"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "mt-3 font-display text-3xl font-semibold sm:text-4xl",
									children: "Pick the hours. Keep the same craftsman."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-moss",
									children: "Month to month. Member discounts on full-room paint and larger drywall. No surprise trip fees."
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-12 grid items-stretch gap-5 lg:grid-cols-3",
							children: PLANS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: cn("relative flex flex-col rounded-2xl border bg-paper p-6 shadow-soft", p.popular ? "border-pine lg:-translate-y-3 lg:p-7" : "border-line"),
								children: [
									p.popular ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-clay px-3 py-1 text-[11px] font-semibold tracking-wide text-accent-foreground uppercase",
										children: "Most homes choose this"
									}) : null,
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: cn("rounded-xl px-4 py-5", p.popular ? "bg-pine text-primary-foreground" : "bg-linen"),
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "text-sm font-medium opacity-80",
												children: p.name
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-1 font-display text-4xl font-semibold tracking-tight",
												children: [
													"$",
													p.price,
													/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
														className: "ml-1 text-base font-sans font-medium opacity-75",
														children: "/mo"
													})
												]
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "mt-2 flex items-center gap-1.5 text-sm opacity-90",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Clock3, { className: "size-4" }), p.hours]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-5 text-sm leading-relaxed text-moss",
										children: p.tagline
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-5 flex-1 space-y-2.5",
										children: p.includes.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex gap-2 text-sm leading-snug",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0 text-pine" }), line]
										}, line))
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-5 text-xs text-moss",
										children: p.extra
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										className: "mt-5 w-full",
										variant: p.popular ? "clay" : "default",
										size: "lg",
										onClick: () => join(p.id),
										children: ["Start ", p.name]
									})
								]
							}, p.id))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "border-t border-line bg-pine text-primary-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "overflow-hidden rounded-2xl",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
								src: "/images/bedroom.jpg",
								alt: "Freshly painted bedroom with linen walls and oak floors",
								className: "aspect-[4/3] w-full object-cover"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-medium tracking-[0.18em] text-clay uppercase",
								children: "Member extras"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-3xl font-semibold sm:text-4xl",
								children: "Full rooms when the punch list is done."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 leading-relaxed text-primary-foreground/80",
								children: "Membership hours stay on small, high-frequency work. When a bedroom, bathroom, or larger drywall job is ready, we quote it at your member rate — often a full master in a single focused day."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-6 space-y-2 text-sm",
								children: [
									"Full bedroom or bathroom paint",
									"Crack repair and texture match before paint",
									"Kitchen refresh billed as extra, not eaten by the 2-hour visit"
								].map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "mt-0.5 size-4 shrink-0" }), t]
								}, t))
							})
						] })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "how",
					className: "border-t border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl font-semibold sm:text-4xl",
							children: "How it works"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 grid gap-6 md:grid-cols-3",
							children: STEPS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "border-t border-pine pt-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-display text-sm font-semibold tracking-widest text-clay",
										children: s.n
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "mt-2 font-display text-2xl font-semibold",
										children: s.title
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 text-sm leading-relaxed text-moss",
										children: s.body
									})
								]
							}, s.n))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "border-t border-line bg-paper",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:items-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/images/caulk.jpg",
							alt: "Precision caulk bead along a tub edge",
							className: "aspect-[4/3] w-full rounded-2xl object-cover"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("blockquote", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl leading-snug font-medium sm:text-3xl",
							children: "“He showed up, knocked out the list in the two hours, and left a note about the hallway cracks. We booked the full paint the next week.”"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
							className: "mt-6 text-sm text-moss",
							children: "M. Chen · Lenexa, 66215"
						})] })]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "area",
					className: "border-t border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-3xl font-semibold sm:text-4xl",
								children: "A tight Johnson County route"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-4 leading-relaxed text-moss",
								children: "Membership only works if the drive time stays honest. We cluster visits in Lenexa and nearby Overland Park and Shawnee neighborhoods so your reserved hour is actually on the tools — not on I-35."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-6 grid gap-2 text-sm",
								children: [
									"Lenexa (home base)",
									"Overland Park",
									"Shawnee"
								].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "size-4 text-pine" }), c]
								}, c))
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/images/porch.jpg",
							alt: "Sunlit suburban porch with a glowing lantern",
							className: "aspect-[16/10] w-full rounded-2xl object-cover"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					id: "faq",
					className: "border-t border-line bg-paper",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-3xl px-4 py-16 sm:px-6 sm:py-20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl font-semibold",
							children: "Questions before you join"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 divide-y divide-line border-y border-line",
							children: FAQS.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
								className: "group py-4",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
									className: "flex cursor-pointer list-none items-center justify-between gap-4 text-left font-medium",
									children: [
										f.q,
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-moss group-open:hidden",
											children: "+"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "hidden text-moss group-open:inline",
											children: "−"
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 pr-8 text-sm leading-relaxed text-moss",
									children: f.a
								})]
							}, f.q))
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "border-t border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto max-w-4xl px-4 py-16 text-center sm:px-6 sm:py-24",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClipboardList, { className: "mx-auto size-8 text-pine" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-4 font-display text-3xl font-semibold sm:text-4xl",
								children: "Ready for a house that stays caught up?"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mx-auto mt-3 max-w-lg text-moss",
								children: "Request a fit visit. We’ll walk the punch list, recommend a tier, and put you on a neighborhood day."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								className: "mt-8",
								onClick: () => join("home-care"),
								children: "Request a membership"
							})
						]
					})
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "border-t border-line bg-pine-deep text-primary-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-col gap-8 px-4 py-12 sm:px-6 md:flex-row md:items-end md:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Logo, {
						inverse: true,
						className: "text-primary-foreground"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-sm text-sm text-primary-foreground/70",
						children: "Handyman membership for Lenexa homes. Painting, drywall, and the monthly punch list."
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-sm text-primary-foreground/70",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Lenexa, Kansas" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1",
								children: "(913) 555-0148"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1",
								children: "hello@porchlightks.com"
							})
						]
					})]
				})
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomePage, {});
}
//#endregion
export { Home as component };
