//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CffNScM8.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-DWGOJ5ks.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DWGOJ5ks.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-asOhj8tP.js"]
	}
} });
//#endregion
export { tsrStartManifest };
