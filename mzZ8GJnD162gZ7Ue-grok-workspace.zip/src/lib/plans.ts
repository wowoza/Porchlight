export type PlanId = "essential" | "home-care" | "premium";

export type Plan = {
  id: PlanId;
  name: string;
  price: number;
  hours: string;
  tagline: string;
  popular?: boolean;
  includes: string[];
  extra: string;
};

export const PLANS: Plan[] = [
  {
    id: "essential",
    name: "Essential",
    price: 109,
    hours: "1 hour each month",
    tagline: "Light upkeep for a newer home or a short punch list.",
    includes: [
      "One reserved hour each month",
      "Small drywall patches and nail pops",
      "Caulk, hardware, and door adjustments",
      "Minor paint touch-ups",
      "Free basic consumables",
      "10% off extra labor and full-room work",
      "Written recap after every visit",
    ],
    extra: "Member extras billed at $135/hour",
  },
  {
    id: "home-care",
    name: "Home Care",
    price: 159,
    hours: "2 hours each month",
    tagline: "The plan most Lenexa homes actually use.",
    popular: true,
    includes: [
      "One focused two-hour visit each month",
      "Full punch-list plus preventive care",
      "Drywall touch-ups across multiple rooms",
      "Caulk, weatherstripping, and hardware",
      "Furniture hanging and fixture swaps",
      "15% off extra labor and full-room work",
      "Preferred scheduling on clustered routes",
    ],
    extra: "Member extras billed at $120/hour",
  },
  {
    id: "premium",
    name: "Premium",
    price: 239,
    hours: "2.5–3 hours each month",
    tagline: "Dedicated time for older homes, busy families, and landlords.",
    includes: [
      "2.5–3 hours monthly, or two shorter visits",
      "Highest-priority scheduling",
      "Proactive seasonal suggestions",
      "Larger free-materials allowance",
      "Bank unused time for one larger project a year",
      "20% off extra labor and materials",
      "The same craftsman who already knows the house",
    ],
    extra: "Member extras billed at $110/hour",
  },
];
