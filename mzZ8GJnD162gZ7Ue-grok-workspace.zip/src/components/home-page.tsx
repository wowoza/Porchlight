import {
  Check,
  ClipboardList,
  Clock3,
  Hammer,
  MapPin,
  Paintbrush,
  ShieldCheck,
  Wrench,
} from "lucide-react";
import { useState } from "react";
import { Toaster } from "sonner";
import { InquiryDialog } from "@/components/inquiry-dialog";
import { Logo } from "@/components/logo";
import { SiteHeader } from "@/components/site-header";
import { Button } from "@/components/ui/button";
import { PLANS, type PlanId } from "@/lib/plans";
import { cn } from "@/lib/utils";

const INCLUDED = [
  { icon: Hammer, title: "Punch-list repairs", body: "Doors, hardware, fixtures, hanging, and the small stuff that never gets done." },
  { icon: Paintbrush, title: "Paint & drywall", body: "Crack repair, patches, touch-ups — plus full rooms billed as member extras." },
  { icon: Wrench, title: "Preventive care", body: "Caulk, weatherstripping, seasonal checks before they become weekend emergencies." },
  { icon: ShieldCheck, title: "Same craftsman", body: "One person who already knows the house, not a new crew every visit." },
];

const STEPS = [
  { n: "01", title: "Pick a plan", body: "Essential, Home Care, or Premium. Month to month. Cancel with 30 days’ notice." },
  { n: "02", title: "Fit visit", body: "We walk the house, set the punch list, and cluster you on a neighborhood route." },
  { n: "03", title: "Monthly care", body: "Your reserved hours arrive. We knock out the list, then quote any full-room extras." },
];

const FAQS = [
  {
    q: "What’s actually included in the monthly hours?",
    a: "Handyman punch-list work: drywall patches, caulk, doors, hardware, minor paint, hanging, and similar small tasks. Full bedrooms, bathrooms, and larger drywall are quoted as extras at your member rate.",
  },
  {
    q: "Can I roll unused hours?",
    a: "Essential and Home Care hours are meant to be used each month so the house stays current. Premium members can bank unused time toward one larger project per year.",
  },
  {
    q: "Do I need to buy materials?",
    a: "Basic consumables — caulk, screws, anchors, small spackle — are included. Everything else is billed at cost plus a modest markup, with your plan discount applied.",
  },
  {
    q: "Where do you work?",
    a: "Lenexa first, plus clustered routes in Overland Park and Shawnee. Tight geography keeps visits on time and the membership profitable to deliver well.",
  },
  {
    q: "Is there a contract?",
    a: "No annual lock-in. Membership is month to month with 30 days’ notice. We’d rather earn the next visit than trap it.",
  },
];

export function HomePage() {
  const [open, setOpen] = useState(false);
  const [plan, setPlan] = useState<PlanId>("home-care");

  function join(id: PlanId = "home-care") {
    setPlan(id);
    setOpen(true);
  }

  return (
    <div id="top" className="min-h-dvh bg-linen text-ink">
      <SiteHeader onJoin={() => join("home-care")} />
      <InquiryDialog open={open} onOpenChange={setOpen} defaultPlan={plan} />
      <Toaster position="top-center" richColors />

      <main>
        <section className="relative overflow-hidden">
          <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[1.05fr_0.95fr] lg:py-20">
            <div>
              <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-line bg-paper px-3 py-1 text-xs font-medium tracking-wide text-moss uppercase">
                <MapPin className="size-3.5 text-pine" />
                Lenexa · Overland Park · Shawnee
              </p>
              <h1 className="font-display text-[2.6rem] leading-[1.08] font-semibold sm:text-5xl lg:text-[3.4rem]">
                The house guy you actually keep.
              </h1>
              <p className="mt-5 max-w-xl text-lg leading-relaxed text-moss">
                A monthly handyman membership for Johnson County homes. Reserved hours for the punch list, plus member rates on full bedrooms, bathrooms, and drywall.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Button size="lg" onClick={() => join("home-care")}>
                  See membership plans
                </Button>
                <Button size="lg" variant="outline" asChild>
                  <a href="#plans">Compare the three tiers</a>
                </Button>
              </div>
              <dl className="mt-10 grid grid-cols-3 gap-4 border-t border-line pt-6">
                {[
                  ["4 yrs", "On the tools"],
                  ["3 tiers", "Clear hours"],
                  ["30-day", "Notice to cancel"],
                ].map(([k, v]) => (
                  <div key={k}>
                    <dt className="font-display text-2xl font-semibold">{k}</dt>
                    <dd className="mt-1 text-xs text-moss">{v}</dd>
                  </div>
                ))}
              </dl>
            </div>
            <div className="relative">
              <div className="overflow-hidden rounded-2xl shadow-soft">
                <img
                  src="/images/craftsman.jpg"
                  alt="Craftsman patching drywall in a bright suburban home"
                  className="aspect-[4/3] w-full object-cover"
                />
              </div>
              <div className="absolute -bottom-5 left-4 max-w-[16rem] rounded-xl border border-line bg-paper p-4 shadow-soft sm:left-8">
                <p className="text-xs font-medium tracking-wide text-moss uppercase">Typical Home Care visit</p>
                <p className="mt-1 font-display text-lg font-semibold leading-snug">
                  Two hours. The list actually gets shorter.
                </p>
              </div>
            </div>
          </div>
        </section>

        <section id="included" className="border-t border-line bg-paper">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20">
            <p className="text-xs font-medium tracking-[0.18em] text-clay uppercase">Membership work</p>
            <h2 className="mt-3 max-w-2xl font-display text-3xl font-semibold sm:text-4xl">
              Built around what a house actually needs every month.
            </h2>
            <div className="mt-10 grid gap-4 sm:grid-cols-2">
              {INCLUDED.map((item) => (
                <article key={item.title} className="rounded-xl border border-line bg-linen p-6">
                  <item.icon className="size-5 text-pine" />
                  <h3 className="mt-4 font-display text-xl font-semibold">{item.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-moss">{item.body}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="plans" className="border-t border-line">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-24">
            <div className="mx-auto max-w-2xl text-center">
              <p className="text-xs font-medium tracking-[0.18em] text-clay uppercase">Three tiers</p>
              <h2 className="mt-3 font-display text-3xl font-semibold sm:text-4xl">
                Pick the hours. Keep the same craftsman.
              </h2>
              <p className="mt-3 text-moss">
                Month to month. Member discounts on full-room paint and larger drywall. No surprise trip fees.
              </p>
            </div>

            <div className="mt-12 grid items-stretch gap-5 lg:grid-cols-3">
              {PLANS.map((p) => (
                <article
                  key={p.id}
                  className={cn(
                    "relative flex flex-col rounded-2xl border bg-paper p-6 shadow-soft",
                    p.popular
                      ? "border-pine lg:-translate-y-3 lg:p-7"
                      : "border-line",
                  )}
                >
                  {p.popular ? (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-clay px-3 py-1 text-[11px] font-semibold tracking-wide text-accent-foreground uppercase">
                      Most homes choose this
                    </span>
                  ) : null}
                  <div className={cn("rounded-xl px-4 py-5", p.popular ? "bg-pine text-primary-foreground" : "bg-linen")}>
                    <p className="text-sm font-medium opacity-80">{p.name}</p>
                    <p className="mt-1 font-display text-4xl font-semibold tracking-tight">
                      ${p.price}
                      <span className="ml-1 text-base font-sans font-medium opacity-75">/mo</span>
                    </p>
                    <p className="mt-2 flex items-center gap-1.5 text-sm opacity-90">
                      <Clock3 className="size-4" />
                      {p.hours}
                    </p>
                  </div>
                  <p className="mt-5 text-sm leading-relaxed text-moss">{p.tagline}</p>
                  <ul className="mt-5 flex-1 space-y-2.5">
                    {p.includes.map((line) => (
                      <li key={line} className="flex gap-2 text-sm leading-snug">
                        <Check className="mt-0.5 size-4 shrink-0 text-pine" />
                        {line}
                      </li>
                    ))}
                  </ul>
                  <p className="mt-5 text-xs text-moss">{p.extra}</p>
                  <Button
                    className="mt-5 w-full"
                    variant={p.popular ? "clay" : "default"}
                    size="lg"
                    onClick={() => join(p.id)}
                  >
                    Start {p.name}
                  </Button>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="border-t border-line bg-pine text-primary-foreground">
          <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2 lg:items-center">
            <div className="overflow-hidden rounded-2xl">
              <img src="/images/bedroom.jpg" alt="Freshly painted bedroom with linen walls and oak floors" className="aspect-[4/3] w-full object-cover" />
            </div>
            <div>
              <p className="text-xs font-medium tracking-[0.18em] text-clay uppercase">Member extras</p>
              <h2 className="mt-3 font-display text-3xl font-semibold sm:text-4xl">
                Full rooms when the punch list is done.
              </h2>
              <p className="mt-4 leading-relaxed text-primary-foreground/80">
                Membership hours stay on small, high-frequency work. When a bedroom, bathroom, or larger drywall job is ready, we quote it at your member rate — often a full master in a single focused day.
              </p>
              <ul className="mt-6 space-y-2 text-sm">
                {[
                  "Full bedroom or bathroom paint",
                  "Crack repair and texture match before paint",
                  "Kitchen refresh billed as extra, not eaten by the 2-hour visit",
                ].map((t) => (
                  <li key={t} className="flex gap-2">
                    <Check className="mt-0.5 size-4 shrink-0" />
                    {t}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        <section id="how" className="border-t border-line">
          <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6 sm:py-20">
            <h2 className="font-display text-3xl font-semibold sm:text-4xl">How it works</h2>
            <div className="mt-10 grid gap-6 md:grid-cols-3">
              {STEPS.map((s) => (
                <article key={s.n} className="border-t border-pine pt-5">
                  <p className="font-display text-sm font-semibold tracking-widest text-clay">{s.n}</p>
                  <h3 className="mt-2 font-display text-2xl font-semibold">{s.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-moss">{s.body}</p>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="border-t border-line bg-paper">
          <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
            <img src="/images/caulk.jpg" alt="Precision caulk bead along a tub edge" className="aspect-[4/3] w-full rounded-2xl object-cover" />
            <blockquote>
              <p className="font-display text-2xl leading-snug font-medium sm:text-3xl">
                “He showed up, knocked out the list in the two hours, and left a note about the hallway cracks. We booked the full paint the next week.”
              </p>
              <footer className="mt-6 text-sm text-moss">M. Chen · Lenexa, 66215</footer>
            </blockquote>
          </div>
        </section>

        <section id="area" className="border-t border-line">
          <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 lg:grid-cols-2">
            <div>
              <h2 className="font-display text-3xl font-semibold sm:text-4xl">A tight Johnson County route</h2>
              <p className="mt-4 leading-relaxed text-moss">
                Membership only works if the drive time stays honest. We cluster visits in Lenexa and nearby Overland Park and Shawnee neighborhoods so your reserved hour is actually on the tools — not on I-35.
              </p>
              <ul className="mt-6 grid gap-2 text-sm">
                {["Lenexa (home base)", "Overland Park", "Shawnee"].map((c) => (
                  <li key={c} className="flex items-center gap-2">
                    <MapPin className="size-4 text-pine" />
                    {c}
                  </li>
                ))}
              </ul>
            </div>
            <img src="/images/porch.jpg" alt="Sunlit suburban porch with a glowing lantern" className="aspect-[16/10] w-full rounded-2xl object-cover" />
          </div>
        </section>

        <section id="faq" className="border-t border-line bg-paper">
          <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6 sm:py-20">
            <h2 className="font-display text-3xl font-semibold">Questions before you join</h2>
            <div className="mt-8 divide-y divide-line border-y border-line">
              {FAQS.map((f) => (
                <details key={f.q} className="group py-4">
                  <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-left font-medium">
                    {f.q}
                    <span className="text-moss group-open:hidden">+</span>
                    <span className="hidden text-moss group-open:inline">−</span>
                  </summary>
                  <p className="mt-2 pr-8 text-sm leading-relaxed text-moss">{f.a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>

        <section className="border-t border-line">
          <div className="mx-auto max-w-4xl px-4 py-16 text-center sm:px-6 sm:py-24">
            <ClipboardList className="mx-auto size-8 text-pine" />
            <h2 className="mt-4 font-display text-3xl font-semibold sm:text-4xl">
              Ready for a house that stays caught up?
            </h2>
            <p className="mx-auto mt-3 max-w-lg text-moss">
              Request a fit visit. We’ll walk the punch list, recommend a tier, and put you on a neighborhood day.
            </p>
            <Button size="lg" className="mt-8" onClick={() => join("home-care")}>
              Request a membership
            </Button>
          </div>
        </section>
      </main>

      <footer className="border-t border-line bg-pine-deep text-primary-foreground">
        <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4 py-12 sm:px-6 md:flex-row md:items-end md:justify-between">
          <div>
            <Logo inverse className="text-primary-foreground" />
            <p className="mt-3 max-w-sm text-sm text-primary-foreground/70">
              Handyman membership for Lenexa homes. Painting, drywall, and the monthly punch list.
            </p>
          </div>
          <div className="text-sm text-primary-foreground/70">
            <p>Lenexa, Kansas</p>
            <p className="mt-1">(913) 555-0148</p>
            <p className="mt-1">hello@porchlightks.com</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
