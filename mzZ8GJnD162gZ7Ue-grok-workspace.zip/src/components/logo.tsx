import { cn } from "@/lib/utils";

export function Logo({
  className,
  inverse = false,
}: {
  className?: string;
  inverse?: boolean;
}) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <svg viewBox="0 0 32 32" className="size-8 shrink-0" aria-hidden="true">
        <rect width="32" height="32" rx="8" className={inverse ? "fill-linen" : "fill-pine"} />
        <path
          d="M16 6.5c.6 0 1.1.4 1.3 1l.5 1.5h2.4a1.5 1.5 0 0 1 1.5 1.5v2.2c0 2.6-1.6 4.8-3.9 5.7v3.1h1.2a.9.9 0 1 1 0 1.8h-6a.9.9 0 1 1 0-1.8h1.2v-3.1A6.1 6.1 0 0 1 10.3 12.7V11.5A1.5 1.5 0 0 1 11.8 10h2.4l.5-1.5A1.4 1.4 0 0 1 16 6.5Z"
          className={inverse ? "fill-pine" : "fill-linen"}
        />
        <path
          d="M13.2 12.2h5.6v1.1c0 1.7-1.2 3.1-2.8 3.1s-2.8-1.4-2.8-3.1v-1.1Z"
          className="fill-clay"
        />
      </svg>
      <span className="font-display text-xl font-semibold tracking-tight">Porchlight</span>
    </span>
  );
}
