import * as Dialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { useState, type FormEvent, type InputHTMLAttributes } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PLANS, type PlanId } from "@/lib/plans";

export function InquiryDialog({
  open,
  onOpenChange,
  defaultPlan,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  defaultPlan: PlanId;
}) {
  const [plan, setPlan] = useState<PlanId>(defaultPlan);
  const [sending, setSending] = useState(false);

  function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    const payload = {
      name: String(data.get("name") || ""),
      phone: String(data.get("phone") || ""),
      email: String(data.get("email") || ""),
      address: String(data.get("address") || ""),
      plan,
      notes: String(data.get("notes") || ""),
      at: new Date().toISOString(),
    };
    setSending(true);
    window.setTimeout(() => {
      const existing = JSON.parse(localStorage.getItem("porchlight-inquiries") || "[]") as unknown[];
      localStorage.setItem("porchlight-inquiries", JSON.stringify([payload, ...existing].slice(0, 20)));
      setSending(false);
      onOpenChange(false);
      toast.success("Request received", {
        description: "We’ll text you within one business day to schedule a fit visit.",
      });
    }, 450);
  }

  return (
    <Dialog.Root
      open={open}
      onOpenChange={(next) => {
        if (next) setPlan(defaultPlan);
        onOpenChange(next);
      }}
    >
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 z-50 bg-ink/45" />
        <Dialog.Content className="fixed top-1/2 left-1/2 z-50 w-[min(92vw,32rem)] max-h-[90dvh] -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-2xl bg-paper p-6 shadow-soft outline-none">
          <div className="mb-5 flex items-start justify-between gap-4">
            <div>
              <Dialog.Title className="font-display text-2xl font-semibold tracking-tight">
                Request a membership
              </Dialog.Title>
              <Dialog.Description className="mt-1 text-sm text-moss">
                Tell us the house and the plan. We’ll confirm a first visit — no long contract.
              </Dialog.Description>
            </div>
            <Dialog.Close className="inline-flex size-10 items-center justify-center rounded-full hover:bg-muted">
              <X className="size-4" />
              <span className="sr-only">Close</span>
            </Dialog.Close>
          </div>
          <form className="grid gap-4" onSubmit={submit}>
            <Field label="Full name" name="name" required placeholder="Alex Rivera" />
            <div className="grid gap-4 sm:grid-cols-2">
              <Field label="Phone" name="phone" required type="tel" placeholder="(913) 555-0148" />
              <Field label="Email" name="email" type="email" placeholder="you@email.com" />
            </div>
            <Field label="Home address" name="address" required placeholder="Lenexa, KS" />
            <div className="grid gap-2">
              <Label>Plan</Label>
              <div className="grid grid-cols-3 gap-2">
                {PLANS.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPlan(p.id)}
                    className={`rounded-lg border px-2 py-2.5 text-center text-xs font-medium transition-colors ${
                      plan === p.id
                        ? "border-pine bg-pine text-primary-foreground"
                        : "border-line bg-linen text-ink hover:border-line-strong"
                    }`}
                  >
                    {p.name}
                    <span className="mt-0.5 block font-normal opacity-80">${p.price}</span>
                  </button>
                ))}
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="notes">What’s on the list?</Label>
              <textarea
                id="notes"
                name="notes"
                rows={3}
                placeholder="Sticky door, hallway cracks, bathroom caulk…"
                className="w-full resize-none rounded-md border border-line bg-paper px-3 py-2 text-sm outline-none focus-visible:border-pine focus-visible:ring-2 focus-visible:ring-pine/20"
              />
            </div>
            <Button type="submit" size="lg" className="mt-1 w-full" disabled={sending}>
              {sending ? "Sending…" : "Send request"}
            </Button>
          </form>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}

function Field({
  label,
  name,
  ...props
}: { label: string; name: string } & InputHTMLAttributes<HTMLInputElement>) {
  return (
    <div className="grid gap-2">
      <Label htmlFor={name}>{label}</Label>
      <Input id={name} name={name} {...props} />
    </div>
  );
}
