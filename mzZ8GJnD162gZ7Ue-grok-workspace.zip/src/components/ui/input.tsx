import type { InputHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

export function Input({ className, ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return (
    <input
      className={cn(
        "flex h-11 w-full rounded-md border border-line bg-paper px-3 text-sm text-ink placeholder:text-moss/70 outline-none transition-colors focus-visible:border-pine focus-visible:ring-2 focus-visible:ring-pine/20",
        className,
      )}
      {...props}
    />
  );
}
